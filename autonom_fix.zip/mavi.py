from __future__ import annotations

import ast
import json
import os
import re
import sys
from pathlib import Path
from typing import Any

from openai import OpenAI, RateLimitError

ROOT = Path(__file__).resolve().parent
SOURCE_FILE = ROOT / "sari_sistem.py"
CANDIDATE_FILE = ROOT / "mavi_aday.json"

PRIMARY_MODEL = (os.getenv("OPENAI_MODEL") or "gpt-5.6-luna").strip()
FALLBACK_MODEL = (os.getenv("MAVI_FALLBACK_MODEL") or "gpt-5.6-terra").strip()
MAX_OUTPUT_TOKENS = 12000

SYSTEM_PROMPT = """
You are MAVİ, the gameplay evolution engineer in an autonomous software loop.

Your ONLY code target is sari_sistem.py.

The most important rule:
A feature is NOT real merely because a new Python method exists.
Every proposed feature must be reachable through the existing exported gameplay
contract and must produce an observable gameplay/progression effect.

The browser currently executes:
- GAME_CONFIG["actions"]
- action energy cost
- action effects: damage, heal, shield, energy
- GAME_CONFIG["player"]
- GAME_CONFIG["progression"]
- GAME_CONFIG["enemies"]
- GAME_CONFIG["shop"] / potion flow
- the existing Game battle flow

Therefore:
- Prefer changing GAME_CONFIG actions/effects or logic used directly by Game.act,
  Game._apply_effects, Game._enemy_turn, Game._win_battle, or buy_potion.
- A new action is good only when it is present in GAME_CONFIG["actions"] and uses
  one or more browser-executable effects.
- DO NOT add a standalone method such as boss_savasi(), esya_satisi(),
  zindan_baskini(), or esya_birlestir() unless the existing game flow actually
  calls it. A dead method is not an evolution.
- Do not add a mechanic that the current browser cannot execute.
- Do not rely on hidden files, external services, APIs, UI edits, or future work.
- Do not change HTML, CSS, JavaScript, workflow files, mavi.py, or kirmizi.py.
- Do not change tests just to make a weak candidate pass.
- Preserve Game, Player, Battle, GAME_CONFIG, --self-test, and --export-web.
- Keep randomness deterministic through the roll argument when relevant.
- Make exactly ONE small but meaningful gameplay improvement.
- The complete source must remain executable.

Before returning the candidate, mentally trace the new/changed mechanic from a
player action or normal battle flow to a changed player/enemy/resource state.
If you cannot trace that path, do not propose it.

Return ONLY valid JSON:
{
  "summary": "short Turkish summary",
  "reason": "why this changes actual gameplay",
  "claimed_change": {
    "kind": "action|player|progression|enemy|shop|engine",
    "id": "identifier or null"
  },
  "file": "sari_sistem.py",
  "content": "COMPLETE replacement source code"
}
"""


def extract_json(text: str) -> dict[str, Any]:
    text = text.strip()

    try:
        value = json.loads(text)
        if isinstance(value, dict):
            return value
    except json.JSONDecodeError:
        pass

    match = re.search(r"\{.*\}\s*$", text, flags=re.DOTALL)
    if match:
        value = json.loads(match.group(0))
        if isinstance(value, dict):
            return value

    raise ValueError("Mavi response was not valid JSON.")


def validate_candidate_text(content: str) -> None:
    if len(content.strip()) < 500:
        raise ValueError("Mavi candidate source is too short.")

    try:
        tree = ast.parse(content)
    except SyntaxError as exc:
        raise ValueError(f"Mavi candidate has a syntax error: {exc}") from exc

    required = [
        "GAME_CONFIG",
        "class Player",
        "class Battle",
        "class Game",
        "def self_test",
        "def export_web",
    ]
    for marker in required:
        if marker not in content:
            raise ValueError(f"Mavi candidate missing required interface: {marker}")

    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in {
                "eval",
                "exec",
                "compile",
                "__import__",
                "breakpoint",
                "input",
            }:
                raise ValueError(f"Forbidden call in candidate: {node.func.id}")


def request_model(client: OpenAI, model: str, prompt: str):
    print(f"Mavi model: {model}")
    return client.responses.create(
        model=model,
        input=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        max_output_tokens=MAX_OUTPUT_TOKENS,
        store=False,
    )


def main() -> int:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("HATA: OPENAI_API_KEY bulunamadı.", file=sys.stderr)
        return 2

    if not SOURCE_FILE.exists():
        print(f"HATA: {SOURCE_FILE} bulunamadı.", file=sys.stderr)
        return 2

    current_source = SOURCE_FILE.read_text(encoding="utf-8")
    client = OpenAI(api_key=api_key)

    prompt = f"""
Improve the actual playable game in the current sari_sistem.py.

Make exactly ONE meaningful gameplay improvement.

IMPORTANT:
The returned source must make the improvement reachable through the existing
  game flow. Do not create a dead helper method and call that 'done'.

Good example:
- Add a new action to GAME_CONFIG["actions"] with a supported effect.
- Change an existing action's real damage/heal/shield/energy behavior.
- Change enemy/player/progression values when the normal battle flow makes the
  effect observable.
- Change Game logic that is actually executed by Game.act or the battle lifecycle.

Bad example:
- Add boss_savasi() but never call it.
- Add a hidden inventory system the browser never uses.
- Add only a description/title/version.
- Add a new effect type the browser does not understand.

Return the COMPLETE sari_sistem.py file in the JSON content field.

CURRENT sari_sistem.py:
--- BEGIN SOURCE ---
{current_source}
--- END SOURCE ---

Return ONLY the requested JSON object.
"""

    models = [PRIMARY_MODEL]
    if FALLBACK_MODEL and FALLBACK_MODEL not in models:
        models.append(FALLBACK_MODEL)

    response = None
    last_error: Exception | None = None

    for model in models:
        try:
            response = request_model(client, model, prompt)
            break
        except RateLimitError as exc:
            last_error = exc
            print(
                f"Rate limit from {model}; trying fallback...",
                file=sys.stderr,
            )
            continue
        except Exception as exc:
            last_error = exc
            print(f"Mavi API hatası ({model}): {exc}", file=sys.stderr)
            return 1

    if response is None:
        print("HATA: Mavi hiçbir kullanılabilir modelden cevap alamadı.", file=sys.stderr)
        if last_error is not None:
            print(str(last_error), file=sys.stderr)
        return 1

    candidate = extract_json(response.output_text)

    if candidate.get("file") != "sari_sistem.py":
        raise ValueError("Mavi yanlış dosyayı hedefledi.")

    content = candidate.get("content")
    if not isinstance(content, str):
        raise ValueError("Mavi geçerli source code üretmedi.")

    content = content.strip()
    validate_candidate_text(content)

    payload = {
        "schema": 2,
        "model": getattr(response, "model", PRIMARY_MODEL),
        "summary": str(candidate.get("summary", "")).strip(),
        "reason": str(candidate.get("reason", "")).strip(),
        "claimed_change": (
            candidate.get("claimed_change")
            if isinstance(candidate.get("claimed_change"), dict)
            else {}
        ),
        "file": "sari_sistem.py",
        "content": content,
    }

    CANDIDATE_FILE.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(
        json.dumps(
            {
                "ok": True,
                "model": payload["model"],
                "summary": payload["summary"],
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
